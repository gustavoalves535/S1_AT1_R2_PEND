const container = document.querySelector(".container");
const registerBtn = document.querySelector(".register__btn");
const loginBtn = document.querySelector(".login__btn");
const username = document.getElementById("Username")
const email = document.getElementById("E-mail")
const password = document.getElementById("Password")
const confirmpassword = document.getElementById("confirmpassword")
const idade = document.getElementById("idade")
const Cpf = document.getElementById("Cpf")
const enviar = document.getElementById("buttonregister")

registerBtn.addEventListener("click", () => {
  container.classList.add("active");
});

loginBtn.addEventListener("click", () => {
  container.classList.remove("active");
});

username.addEventListener("input", (event) => {


  const regex = /^[a-zA-ZÀ-ÿ\s]+$/;

  console.log(regex.test(event.target.value))

  if (event.target.value.length < 3) {
    console.log("o nome precisa ter no minimo 3 caracteres")
  }
  if (!regex.test(event.target.value)) {
    console.log("nome inválido!")
  }


})

const checkusermane = () => {
  const NomeRegex = /^[a-zA-ZÀ-ÿ\s]+$/;

  return NomeRegex.test(NomeRegex.value) && username.value.length > 3
}


email.addEventListener("input", (event) => {
  const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  console.log(regexEmail.test(event.target.value))
})

const checkEmail = () => {
    const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
     return (emailregex.test(email.value))
}

password.addEventListener("input", (event) => {

  const Maiuscula = /[A-Z]/.test(event.target.value);
  const Caracterespecial = /[!@#$%^&*(),.?":{}|<>]/.test(event.target.value)
  const Numero = /[0-9]/.test(event.target.value)
  const tamanhoSenha = event.target.value < 10
  if (!Maiuscula) {
    console.log(" a senha precia de uma letra maiuscula")
  }
  if (!Caracterespecial) {
    console.log("a senha precisa de um caracter especial")
  }

  if (!Numero) {
    console.log("a senha precisa ter um numero no minimo")
  }

  if (!tamanhoSenha) {
    console.log("a senha precisa de no minimo 10 caracteres")
  } 
})

const checkpassword = () => {
 const senhaRegex = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*(),.?":{}|<>]).{10,}$/;

 return passwordregex.test(password.value)
}

confirmpassword.addEventListener("input", (event) => {
  if (event.target.value === password.value) {
    console.log("senha correta")
  } else {
    console.log("senha inválida")
  }
})

const checkconfirmpassword = () => {
    if (confirmpassword.value === password.value) {
    console.log("senha correta")
  } else {
    console.log("senha inválida")
  }
}



idade.addEventListener("input", (event) => {
  const idade = event.target.value

  if (idade < 18) {
    console.log("precisa ter no minimo 18 anos")
    return false
  } else {
    console.log("idade confirmada")
    return true
  }

})
const checkIdade = () => {
  if (idade < 18) {
    return false
  } else {
    return true
  }

}

Cpf.addEventListener("input", (event) => {
  const regex = /^\d{11,}$/.test(event.target.value);

  if (regex) {
    console.log("Cpf válido")
  } else {
    console.log("cpf inválido");
  }


})

const checkcpf = () => {

    if (Cpf.value.length === 11) {
    console.log("Cpf válido")
  } else {
    console.log("cpf inválido");
  }

}
enviar.addEventListener("submit",  (event) => {
  const regex = /^\d{11,}$/.test(event.target.value);
  if (regex) {
    console.log("certo")
  } else {
    console.log("errado");
  }
})




